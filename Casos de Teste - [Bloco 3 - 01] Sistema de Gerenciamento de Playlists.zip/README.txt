Arquivo zip gerado em: 19/07/2021 03:14:21 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: [Bloco 3 - 01] Sistema de Gerenciamento de Playlists